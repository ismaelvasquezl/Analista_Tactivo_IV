"""
Tests OFFLINE del motor analítico (no requieren red ni FBref).
Validan que las métricas derivadas son correctas con datos sintéticos.

Ejecutar:  python -m pytest tests/ -q      (o:  python tests/test_metrics.py)
"""
import os, sys, math
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pandas as pd
from src import metrics as M
from src import compare as CMP
from src import insights as INS


def approx(a, b, tol=1e-6):
    return abs(a - b) < tol


def test_per90():
    assert approx(M.per90(2, 90), 2.0)
    assert approx(M.per90(1, 45), 2.0)       # medio partido -> se duplica
    assert math.isnan(M.per90(1, 0))         # minutos 0 -> NaN, no crash


def test_attack_metrics():
    df = pd.DataFrame({"xg": [9.0], "npxg": [7.2], "xa": [4.5], "minutes": [900]})
    out = M.add_attack_metrics(df)
    assert approx(out["xG_per_90"][0], 0.9)
    assert approx(out["npxG_per_90"][0], 0.72)
    assert approx(out["xA_per_90"][0], 0.45)
    assert approx(out["threat_score"][0], 1.35)


def test_ppda_and_pressing():
    # 300 pases rival / 40 acciones defensivas = 7.5 -> presión ALTA
    val = M.ppda(300, 40)
    assert approx(val, 7.5)
    assert M.classify_pressing(val) == "HIGH"
    assert M.classify_pressing(12.0) == "MODERATE"
    assert M.classify_pressing(18.0) == "LOW"
    assert math.isnan(M.ppda(300, 0))        # sin acciones -> NaN


def test_pressure_success():
    assert approx(M.pressure_success_rate(45, 150), 0.30)
    assert math.isnan(M.pressure_success_rate(1, 0))


def test_shot_profile():
    prof = M.team_tactical_profile({
        "xG_per_90": 1.4, "npxG_per_90": 1.2, "xA_per_90": 0.9,
        "possession": 55, "ppda": 8.0, "shots_per_90": 15.0,
    })
    assert prof["pressing_style"] == "HIGH"
    # 1.2 npxG / 15 shots = 0.08 npxG por remate y 15 remates -> volumen alto/baja calidad
    assert prof["shot_profile"] == "VOLUMEN_ALTO_BAJA_CALIDAD"


def test_comparison_and_advantages():
    df = pd.DataFrame(
        {"xG_per_90": [1.6, 1.2, 1.1], "xA_per_90": [1.1, 0.9, 0.8],
         "ppda": [8.0, 11.0, 12.0], "possession": [56, 52, 50],
         "pressures_per_90": [160, 140, 130], "threat_score": [2.7, 2.1, 1.9]},
        index=["Coquimbo Unido", "Colo-Colo", "Palestino"],
    )
    comp = CMP.build_comparison(df, rivals=["Colo-Colo", "Palestino"])
    assert list(comp.index) == ["Coquimbo Unido", "Colo-Colo", "Palestino"]
    adv = CMP.advantages(df, rivals=["Colo-Colo", "Palestino"])
    # Coquimbo mejor en xG, xA, threat y con PPDA menor (mejor) -> todas ventajas
    assert "xG_per_90" in adv["ventajas"]
    assert "ppda" in adv["ventajas"]           # menor es mejor
    assert adv["detalle"]["ppda"]["favorable"] is True


def test_insights_rules():
    team = {"ppda": 8.0, "xG_per_90": 1.6, "pressure_success_rate": 0.20, "shot_profile": "VOLUMEN_ALTO_BAJA_CALIDAD"}
    opp = {"ppda": 12.0, "xG_per_90": 1.0}
    recs = INS.matchup_recommendations(team, opp)
    joined = " ".join(recs)
    assert "VENTAJA presión" in joined
    assert "VENTAJA creación" in joined
    assert "ALERTA presión inefectiva" in joined
    assert "selección de tiro" in joined


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    passed = 0
    for fn in fns:
        fn(); passed += 1
        print(f"  ✓ {fn.__name__}")
    print(f"\n{passed}/{len(fns)} tests OK (offline).")
