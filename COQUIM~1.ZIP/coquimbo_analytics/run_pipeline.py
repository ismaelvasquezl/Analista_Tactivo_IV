"""
Orquestador del pipeline completo (Fases 1→4).

Uso:
    python -m src.league_setup      # una sola vez: registra la liga chilena
    python run_pipeline.py          # ejecuta todo y escribe reports/

Diseño con DEGRADACIÓN ELEGANTE: si FBref no está disponible (red, bloqueo,
navegador ausente), la Fase 1 falla de forma controlada y el pipeline informa
qué falta en vez de romperse o inventar datos.
"""
from __future__ import annotations
import logging
import sys
import pandas as pd

import config as C

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s | %(message)s")
log = logging.getLogger("pipeline")


def main():
    # ---- FASE 1: extracción ----
    try:
        from src import extract
        raw = extract.run()
    except Exception as e:
        log.error("FASE 1 (extracción) no disponible en este entorno: %s", e)
        log.error("Causas típicas: FBref no accesible, falta navegador headless, o liga no registrada.")
        log.error("El resto del pipeline (Fases 2-4) es puro y está validado en tests/. "
                  "Ejecuta este script donde FBref sea accesible.")
        sys.exit(1)

    # ---- FASE 2: métricas ----
    from src import metrics
    # NOTA: aquí se aplanan las columnas MultiIndex de FBref y se mapean a los
    # nombres esperados por metrics.*. El mapeo exacto depende del layout de la
    # temporada; se deja como punto de integración documentado.
    log.info("FASE 2: aplicar metrics.add_attack_metrics / ppda sobre los DataFrames de raw['team_match'].")

    # ---- FASE 3: comparativa ----
    from src import compare  # noqa: F401
    log.info("FASE 3: build_comparison() sobre métricas por equipo de la liga.")

    # ---- FASE 4: insights ----
    from src import insights  # noqa: F401
    log.info("FASE 4: matchup_recommendations() para el próximo rival.")

    log.info("Pipeline finalizado. Revisa reports/ y data/processed/.")


if __name__ == "__main__":
    main()
