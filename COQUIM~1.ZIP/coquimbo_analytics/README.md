# Coquimbo Unido · Pipeline de Análisis Táctico (FBref)

Sistema de ingeniería de datos futbolísticos para analizar el rendimiento de
**Coquimbo Unido** (Primera División de Chile) y sus rivales, con FBref como
fuente primaria vía la librería `soccerdata`.

> **Contexto real (verificado, jul-2026):** Coquimbo Unido fue **campeón de la
> Primera División de Chile 2025** — su primer título en la historia, con DT
> Esteban González y una racha de 14 victorias consecutivas. En **2026** defiende
> el título y alcanzó por primera vez los **cuartos de final de la Copa
> Libertadores** como líder del Grupo B (10 pts; 3-0 a Tolima). El análisis debe
> leerse sobre un equipo *ganador reciente*, no un equipo en crisis.

---

## ⚠️ Lo que tienes que saber antes de correrlo (gotchas reales)

Estos puntos se verificaron ejecutando `soccerdata 1.9.1`; **no están en el
prompt original** y romperían el pipeline si no se atienden:

1. **Chile NO viene incluido en soccerdata.**
   `sd.FBref.available_leagues()` solo trae Big 5 + torneos FIFA/UEFA. Hay que
   **registrar la liga** antes de usarla:
   ```bash
   python -m src.league_setup      # escribe ~/soccerdata/config/league_dict.json
   ```
   (Lo hace `src/league_setup.py`; el nombre FBref de la competición es
   `"Primera División"`.)

2. **La API real difiere del prompt.** No existe
   `fbref.read_team_match_stats(team="Coquimbo Unido")` como método aislado por
   equipo. La API real (envuelta en `src/extract.py`) es:
   `read_schedule()`, `read_team_season_stats(stat_type, opponent_stats)`,
   `read_player_season_stats(stat_type)`,
   `read_team_match_stats(stat_type, opponent_stats, team)`.

3. **soccerdata usa un navegador headless** (SeleniumBase) para saltar la
   protección anti-bot de FBref. Necesitas Chromium/Chrome instalado. El
   *rate-limiting* y la caché los gestiona soccerdata internamente (no hace falta
   el `time.sleep(3-5)` manual salvo que construyas un scraper de respaldo).

4. **PPDA es una aproximación.** FBref no expone el corte zonal (pases del rival
   en su 60% de campo) en las tablas agregadas. `metrics.ppda()` documenta y
   marca la aproximación; el PPDA zonal exacto requiere *event data*.

5. **Temporada = año calendario.** La liga chilena usa `SEASON="2026"` (no
   `"2025-2026"`). FBref publica 2025 y 2026 por separado.

---

## Estructura

```
coquimbo_analytics/
├── config.py                # equipo, liga, temporada, rivales, benchmarks
├── run_pipeline.py          # orquestador Fases 1→4 (degradación elegante)
├── requirements.txt
├── src/
│   ├── league_setup.py      # FASE 0 · registra Chile en soccerdata
│   ├── extract.py           # FASE 1 · extracción (API real de soccerdata)
│   ├── metrics.py           # FASE 2 · métricas puras y testeables
│   ├── compare.py           # FASE 3 · comparativa vs rivales
│   └── insights.py          # FASE 4 · recomendaciones por reglas
├── tests/
│   └── test_metrics.py      # 7 tests OFFLINE (no requieren red) — todos en verde
├── data/{raw,processed}/    # parquet de FBref (no versionar los crudos)
└── reports/                 # salidas: perfil táctico, comparativa, match report
```

## Instalación y uso

```bash
pip install -r requirements.txt
python -m src.league_setup          # una sola vez
python run_pipeline.py              # ejecuta todo donde FBref sea accesible
python -m pytest tests/ -q          # valida el motor analítico sin red
```

## Métricas implementadas

| Bloque | Métricas |
|---|---|
| Ofensivo | xG, xG/90, npxG/90, xA/90, **threat_score** (xG/90+xA/90), shots/90, npxG por remate, SCA, progressive passes/carries |
| Presión / defensa | **PPDA** (aprox. documentada), pressures/90, pressure success %, tackles+int/90, clearances, blocks |
| Posesión | possession %, pass completion %, touches en área rival, field tilt |
| Perfiles | estilo de presión (HIGH/MODERATE/LOW), perfil de remate (volumen vs calidad) |

## Schema de datos (salida de Fase 1)

Todos los DataFrames de FBref traen **columnas MultiIndex** (categoría, métrica)
e índice por `(league, season, team[, game])`. `extract.py` guarda cada tabla en
`data/raw/*.parquet`. Antes de Fase 2 se aplanan columnas y se mapean nombres a
los que esperan las funciones de `metrics.py` (`xg`, `npxg`, `xa`, `minutes`, …).

| Tabla | Fuente | Clave | Uso |
|---|---|---|---|
| `schedule` | `read_schedule` | league·season·game | tabla, forma, local/visita, rivales reales |
| `team_season_<stat>` (+`_vs`) | `read_team_season_stats` | team | perfil de temporada y percentiles de liga |
| `player_season_<stat>` | `read_player_season_stats` | player | rankings xG/90, xA/90, pressures/90 |
| `team_match_<stat>` | `read_team_match_stats` | team·game | forma por partido, PPDA por partido |

## Criterios de éxito (mapeo)

- **Pipeline sin errores 30 días** → `run_pipeline.py` con degradación elegante + caché de soccerdata.
- **Actualización semanal** → re-ejecutar tras cada jornada (`NO_CACHE=True` puntual).
- **Insights correlacionan >70%** → validar `insights` contra resultados reales por jornada (backtest).
- **Comparativa medible** → `compare.build_comparison()` + `advantages()`.
- **Reporte accionable** → `insights.executive_insights()` / `matchup_recommendations()`.

## Nota metodológica de honestidad

Este repositorio **no incluye valores numéricos de xG/PPDA de Coquimbo** porque el
entorno donde se generó no tenía acceso de red a FBref (bloqueado). El código está
**verificado**: los 7 tests del motor analítico pasan con datos sintéticos y todos
los módulos compilan. Al ejecutarlo en un entorno con FBref accesible, `data/` y
`reports/` se poblarán con datos reales. Nunca se rellenan métricas a mano.
