"""
Configuración central del pipeline de análisis táctico de Coquimbo Unido.
Editar aquí temporada, equipo, rivales y parámetros de scraping.
"""
from pathlib import Path

# --- Identidad del proyecto ---
TEAM = "Coquimbo Unido"

# Clave de liga personalizada que registramos en soccerdata (ver src/league_setup.py).
# OJO: soccerdata NO trae Chile por defecto (solo Big 5 + torneos FIFA/UEFA).
LEAGUE = "CHI-Primera División"

# La liga chilena es de año calendario -> la temporada es un único año.
# FBref publica 2025 y 2026 por separado. Coquimbo fue CAMPEÓN 2025.
SEASON = "2026"

# Rivales de referencia para la comparativa competitiva.
# RECOMENDACIÓN: derivar el top-5 real desde la tabla 2026 (read_schedule),
# no fijarlo a mano. Esta lista es el punto de partida.
RIVALS = [
    "Universidad de Chile",
    "Colo-Colo",
    "Universidad Católica",
    "Palestino",
    "Audax Italiano",
]

# --- Tipos de estadística disponibles en FBref vía soccerdata ---
# Válidos para read_team_season_stats / read_team_match_stats:
TEAM_STAT_TYPES = [
    "standard", "shooting", "passing", "passing_types",
    "goal_shot_creation", "defense", "possession", "misc", "keeper", "keeper_adv",
]
PLAYER_STAT_TYPES = TEAM_STAT_TYPES + ["playing_time"]

# --- Rutas ---
ROOT = Path(__file__).parent
DATA_RAW = ROOT / "data" / "raw"
DATA_PROC = ROOT / "data" / "processed"
REPORTS = ROOT / "reports"
for _p in (DATA_RAW, DATA_PROC, REPORTS):
    _p.mkdir(parents=True, exist_ok=True)

# --- Scraping / buenas prácticas ---
# soccerdata gestiona su propia caché y su propio navegador headless.
# Estas opciones controlan el comportamiento del pipeline:
NO_CACHE = False        # True = forzar re-descarga (evitar en producción por rate-limits)
REQUEST_DELAY = 4       # segundos entre descargas manuales de respaldo (fallback scraper)
USER_AGENT = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
              "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36")

# --- Benchmarks de interpretación táctica (documentados, editables) ---
BENCHMARKS = {
    "ppda_high_press": 10.0,     # < 10  => presión alta
    "ppda_low_press": 15.0,      # > 15  => presión baja
    "pressure_success_good": 0.30,
    "threat_ratio_advantage": 1.20,  # 20% por encima del rival = ventaja clara
}
