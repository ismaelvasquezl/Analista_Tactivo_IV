"""
FASE 3 — Comparativa competitiva (Competitive Intelligence).

Construye la tabla comparativa Coquimbo vs rivales y detecta ventajas/
desventajas relativas. Trabaja sobre un DataFrame de métricas por equipo
(una fila por club) — se puede alimentar del output de Fase 2 o de un CSV.
"""
from __future__ import annotations
import pandas as pd
import config as C

COMPARE_COLS = ["xG_per_90", "xA_per_90", "ppda", "possession", "pressures_per_90", "threat_score"]


def build_comparison(team_metrics: pd.DataFrame, team=C.TEAM, rivals=None) -> pd.DataFrame:
    """team_metrics: index=nombre de equipo, columnas=métricas.
    Devuelve la tabla filtrada a Coquimbo + rivales, en el orden pedido."""
    rivals = rivals or C.RIVALS
    wanted = [team] + [r for r in rivals if r in team_metrics.index]
    cols = [c for c in COMPARE_COLS if c in team_metrics.columns]
    return team_metrics.loc[[w for w in wanted if w in team_metrics.index], cols].round(2)


def advantages(team_metrics: pd.DataFrame, team=C.TEAM, rivals=None) -> dict:
    """Compara Coquimbo contra la MEDIA de sus rivales.
    Ventaja = mejor que la media rival (con dirección correcta por métrica).
    En PPDA, MENOR es mejor; en el resto, MAYOR es mejor."""
    rivals = rivals or C.RIVALS
    present_rivals = [r for r in rivals if r in team_metrics.index]
    if team not in team_metrics.index or not present_rivals:
        return {"error": "faltan equipos en el dataset"}

    lower_is_better = {"ppda"}
    res = {"ventajas": [], "desventajas": [], "detalle": {}}
    t = team_metrics.loc[team]
    rmean = team_metrics.loc[present_rivals].mean(numeric_only=True)

    for c in COMPARE_COLS:
        if c not in team_metrics.columns or pd.isna(t.get(c)):
            continue
        diff = t[c] - rmean[c]
        better = (diff < 0) if c in lower_is_better else (diff > 0)
        res["detalle"][c] = {"coquimbo": round(float(t[c]), 2),
                             "media_rival": round(float(rmean[c]), 2),
                             "delta": round(float(diff), 2),
                             "favorable": bool(better)}
        (res["ventajas"] if better else res["desventajas"]).append(c)
    return res
