"""
FASE 4 — Insights accionables (Decision Support).

Genera recomendaciones basadas en reglas explícitas sobre el perfil propio y
el del rival. Reglas transparentes y editables (no caja negra).
"""
from __future__ import annotations
import pandas as pd
import config as C


def matchup_recommendations(team: dict, opponent: dict, bench=None) -> list[str]:
    """team / opponent: dicts de métricas (xG_per_90, ppda, pressure_success_rate...)."""
    bench = bench or C.BENCHMARKS
    recs = []

    def has(d, k):
        return k in d and d[k] is not None and not pd.isna(d[k])

    # Presión relativa (PPDA: menor = más intenso)
    if has(team, "ppda") and has(opponent, "ppda"):
        if team["ppda"] < opponent["ppda"]:
            recs.append(f"VENTAJA presión: PPDA {team['ppda']:.1f} < rival {opponent['ppda']:.1f}. "
                        "Sostener presión alta para forzar pérdidas en zona de construcción rival.")
        else:
            recs.append(f"RIESGO presión: el rival presiona más (PPDA {opponent['ppda']:.1f} < {team['ppda']:.1f}). "
                        "Preparar salida limpia y apoyos entre líneas para evitar pérdidas.")

    # Creación de ocasiones
    if has(team, "xG_per_90") and has(opponent, "xG_per_90") and opponent["xG_per_90"] > 0:
        ratio = team["xG_per_90"] / opponent["xG_per_90"]
        if ratio >= bench["threat_ratio_advantage"]:
            recs.append(f"VENTAJA creación: xG/90 {ratio:.2f}x el del rival. "
                        "Buscar volumen de ocasión; el modelo favorece a Coquimbo en juego largo.")
        elif ratio <= 1 / bench["threat_ratio_advantage"]:
            recs.append("ALERTA creación: el rival genera más xG/90. "
                        "Priorizar orden defensivo y transición rápida sobre posesión estéril.")

    # Efectividad de presión propia
    if has(team, "pressure_success_rate") and team["pressure_success_rate"] < 0.25:
        recs.append("ALERTA presión inefectiva (<25%): revisar los 'triggers' de presión "
                    "(pase hacia atrás, control orientado hacia banda) para no dejar el bloque partido.")

    # Perfil de remate propio
    if team.get("shot_profile") == "VOLUMEN_ALTO_BAJA_CALIDAD":
        recs.append("Ajuste ofensivo: mucho remate de baja calidad. Trabajar selección de tiro "
                    "y llegada a zonas de mayor npxG por remate (área, half-spaces).")
    elif team.get("shot_profile") == "VOLUMEN_BAJO_ALTA_CALIDAD":
        recs.append("Fortaleza ofensiva: pocas pero buenas. Aumentar volumen sin perder calidad "
                    "(más llegadas de segunda línea).")

    return recs


def executive_insights(profile: dict, comparison: dict) -> list[str]:
    """5 insights ejecutivos combinando perfil propio + comparativa."""
    out = []
    if profile.get("pressing_style"):
        out.append(f"Estilo de presión: {profile['pressing_style']} (PPDA≈{profile.get('ppda')}).")
    if profile.get("shot_profile"):
        out.append(f"Perfil de remate: {profile['shot_profile']}.")
    for c in comparison.get("ventajas", [])[:2]:
        d = comparison["detalle"][c]
        out.append(f"Ventaja vs rivales en {c}: {d['coquimbo']} vs media {d['media_rival']}.")
    for c in comparison.get("desventajas", [])[:2]:
        d = comparison["detalle"][c]
        out.append(f"A corregir en {c}: {d['coquimbo']} vs media rival {d['media_rival']}.")
    return out[:5]
