"""
FASE 1 — Extracción de datos (Data Engineering).

Usa la API REAL de soccerdata 1.9.1 (verificada):
    read_schedule()
    read_team_season_stats(stat_type=..., opponent_stats=...)
    read_player_season_stats(stat_type=...)
    read_team_match_stats(stat_type=..., opponent_stats=..., team=...)

Nota: NO existe `read_team_match_stats(team=...)` como método por-equipo aislado
del prompt original; se lee a nivel de LIGA y se filtra por equipo. Aquí lo
encapsulamos para que el resto del pipeline no dependa de esos detalles.

Todas las descargas se guardan en data/raw como parquet para reproducibilidad.
"""
from __future__ import annotations
import logging
from pathlib import Path
import pandas as pd

import config as C
from src.league_setup import register_chile_league

log = logging.getLogger("extract")


def get_reader():
    """Instancia el lector de FBref, registrando antes la liga chilena."""
    register_chile_league()
    import soccerdata as sd  # import tardío: la liga se lee al importar
    return sd.FBref(leagues=C.LEAGUE, seasons=C.SEASON, no_cache=C.NO_CACHE)


def _save(df: pd.DataFrame, name: str) -> pd.DataFrame:
    out = C.DATA_RAW / f"{name}.parquet"
    df.to_parquet(out)
    log.info("guardado %s (%d filas)", out.name, len(df))
    return df


def extract_schedule(fb) -> pd.DataFrame:
    """Calendario + resultados de toda la liga (para tabla y forma)."""
    return _save(fb.read_schedule(), "schedule")


def extract_team_season(fb) -> dict[str, pd.DataFrame]:
    """Stats acumuladas de temporada por equipo, para cada stat_type.
    Incluye versión 'opponent' (lo que CONCEDE cada equipo) para PPDA/xGA."""
    tables = {}
    for st in C.TEAM_STAT_TYPES:
        try:
            tables[st] = _save(fb.read_team_season_stats(stat_type=st), f"team_season_{st}")
            tables[f"{st}__vs"] = _save(
                fb.read_team_season_stats(stat_type=st, opponent_stats=True),
                f"team_season_{st}_vs",
            )
        except Exception as e:  # una stat puede no existir para la liga
            log.warning("team_season_stats(%s) falló: %s", st, e)
    return tables


def extract_player_season(fb) -> dict[str, pd.DataFrame]:
    tables = {}
    for st in C.PLAYER_STAT_TYPES:
        try:
            tables[st] = _save(fb.read_player_season_stats(stat_type=st), f"player_season_{st}")
        except Exception as e:
            log.warning("player_season_stats(%s) falló: %s", st, e)
    return tables


def extract_team_match(fb, team: str | None = None) -> dict[str, pd.DataFrame]:
    """Stats POR PARTIDO del equipo (y del rival) — base del análisis de forma
    y del cálculo de PPDA por partido."""
    team = team or C.TEAM
    tables = {}
    for st in ["schedule", "shooting", "passing", "defense", "possession", "misc", "keeper"]:
        try:
            tables[st] = _save(
                fb.read_team_match_stats(stat_type=st, team=team, opponent_stats=True),
                f"team_match_{st}",
            )
        except Exception as e:
            log.warning("team_match_stats(%s) falló: %s", st, e)
    return tables


def run() -> dict:
    """Orquesta la Fase 1 completa. Devuelve un dict de DataFrames."""
    fb = get_reader()
    data = {
        "schedule": extract_schedule(fb),
        "team_season": extract_team_season(fb),
        "player_season": extract_player_season(fb),
        "team_match": extract_team_match(fb, C.TEAM),
    }
    log.info("FASE 1 completa. Datos crudos en %s", C.DATA_RAW)
    return data


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s | %(message)s")
    run()
