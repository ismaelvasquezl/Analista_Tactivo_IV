"""
FASE 2 — Motor de métricas (Analytics Engine).

Funciones PURAS y testeables sin red (ver tests/test_metrics.py).
Reciben números o DataFrames pequeños y devuelven métricas derivadas.
La lógica de negocio queda separada de la extracción para poder validarla.
"""
from __future__ import annotations
import numpy as np
import pandas as pd


# ---------------------------------------------------------------- normalización
def per90(total: float, minutes: float) -> float:
    """Normaliza cualquier acumulado a por-90'. Robusto ante minutos 0/NaN."""
    if minutes is None or minutes <= 0 or pd.isna(minutes):
        return np.nan
    return float(total) / (minutes / 90.0)


def add_per90_columns(df: pd.DataFrame, cols: list[str], minutes_col: str = "minutes") -> pd.DataFrame:
    """Agrega columnas <col>_per_90 para cada métrica ofensiva indicada."""
    out = df.copy()
    m = out[minutes_col]
    for c in cols:
        if c in out.columns:
            out[f"{c}_per_90"] = out.apply(lambda r: per90(r[c], r[minutes_col]), axis=1)
    return out


# ---------------------------------------------------------------- ataque
def threat_score(xg_per_90: float, xa_per_90: float) -> float:
    """Contribución total al ataque = xG/90 + xA/90."""
    return float(np.nansum([xg_per_90, xa_per_90]))


def add_attack_metrics(df: pd.DataFrame, minutes_col: str = "minutes") -> pd.DataFrame:
    """Espera columnas: xg, npxg, xa (nombres FBref ya aplanados).
    Crea xG_per_90, npxG_per_90, xA_per_90 y threat_score."""
    out = df.copy()
    mapping = {"xg": "xG_per_90", "npxg": "npxG_per_90", "xa": "xA_per_90"}
    for src, dst in mapping.items():
        if src in out.columns:
            out[dst] = out.apply(lambda r: per90(r[src], r[minutes_col]), axis=1)
    if {"xG_per_90", "xA_per_90"}.issubset(out.columns):
        out["threat_score"] = out["xG_per_90"].fillna(0) + out["xA_per_90"].fillna(0)
    return out


# ---------------------------------------------------------------- presión / defensa
def ppda(opp_passes_att_third: float, defensive_actions: float) -> float:
    """PPDA = pases del rival en su zona de construcción / acciones defensivas.
    Menor = presión más agresiva.

    NOTA DE HONESTIDAD: el PPDA 'canónico' usa pases del rival en su 60% de
    campo. FBref no expone ese corte zonal en las tablas agregadas, así que:
      - Con datos por partido (opponent_stats=True) se aproxima con
        pases completados del rival / (tackles + intercepciones + entradas).
      - Para el PPDA zonal exacto se necesita event data (StatsBomb/Opta) o
        FBref shot/possession events. Se marca como APROXIMACIÓN.
    """
    if defensive_actions is None or defensive_actions <= 0 or pd.isna(defensive_actions):
        return np.nan
    return float(opp_passes_att_third) / float(defensive_actions)


def defensive_actions(tackles: float, interceptions: float, challenges: float = 0) -> float:
    return float(np.nansum([tackles, interceptions, challenges]))


def pressure_success_rate(successful: float, total: float) -> float:
    if total is None or total <= 0 or pd.isna(total):
        return np.nan
    return float(successful) / float(total)


def classify_pressing(mean_ppda: float, high=10.0, low=15.0) -> str:
    if pd.isna(mean_ppda):
        return "UNKNOWN"
    if mean_ppda < high:
        return "HIGH"
    if mean_ppda < low:
        return "MODERATE"
    return "LOW"


# ---------------------------------------------------------------- percentiles liga
def league_percentiles(df: pd.DataFrame, metric_cols: list[str]) -> pd.DataFrame:
    """Percentil de cada equipo/jugador respecto a la liga, por métrica."""
    out = pd.DataFrame(index=df.index)
    for c in metric_cols:
        if c in df.columns:
            out[f"{c}_pct"] = df[c].rank(pct=True) * 100
    return out


# ---------------------------------------------------------------- perfil de equipo
def team_tactical_profile(season_row: dict) -> dict:
    """Sintetiza un perfil táctico legible desde un dict de métricas de equipo.
    Todas las claves son opcionales; lo ausente queda como None (no se inventa)."""
    p = {}
    p["xG_per_90"] = season_row.get("xG_per_90")
    p["npxG_per_90"] = season_row.get("npxG_per_90")
    p["xA_per_90"] = season_row.get("xA_per_90")
    p["threat_score"] = season_row.get("threat_score")
    p["possession"] = season_row.get("possession")
    p["ppda"] = season_row.get("ppda")
    p["pressing_style"] = classify_pressing(season_row.get("ppda", np.nan))

    # Perfil de remate: volumen vs calidad
    shots90 = season_row.get("shots_per_90")
    npxg_per_shot = None
    if shots90 and season_row.get("npxG_per_90"):
        npxg_per_shot = season_row["npxG_per_90"] / shots90 if shots90 else None
    p["shots_per_90"] = shots90
    p["npxg_per_shot"] = npxg_per_shot
    if npxg_per_shot is not None and shots90 is not None:
        if shots90 >= 13 and npxg_per_shot < 0.10:
            p["shot_profile"] = "VOLUMEN_ALTO_BAJA_CALIDAD"
        elif shots90 < 11 and npxg_per_shot >= 0.11:
            p["shot_profile"] = "VOLUMEN_BAJO_ALTA_CALIDAD"
        else:
            p["shot_profile"] = "EQUILIBRADO"
    else:
        p["shot_profile"] = None
    return p
