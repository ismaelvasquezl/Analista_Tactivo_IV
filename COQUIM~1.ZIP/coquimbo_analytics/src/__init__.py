"""Pipeline de análisis táctico de Coquimbo Unido (FBref)."""
