"""
FASE 0 — Registro de la liga chilena en soccerdata.

PROBLEMA REAL (verificado con soccerdata 1.9.1):
    sd.FBref.available_leagues() -> solo Big 5 + torneos FIFA/UEFA.
    Chile NO está incluido. Por eso `sd.FBref(leagues="CHI-Primera División")`
    falla con "invalid league" hasta registrar la liga manualmente.

SOLUCIÓN:
    soccerdata lee ligas extra desde  <SOCCERDATA_DIR>/config/league_dict.json
    (por defecto ~/soccerdata/config/league_dict.json).
    Aquí escribimos/mergeamos la entrada de Chile con el nombre que FBref usa
    para la competición ("Primera División").

Ejecutar una vez:  python -m src.league_setup
"""
import json
import os
from pathlib import Path

# Nombre EXACTO de la competición en FBref (comp id 35: "Primera-Division").
FBREF_COMP_NAME = "Primera División"

CHILE_ENTRY = {
    "CHI-Primera División": {
        "FBref": FBREF_COMP_NAME,
        "ESPN": "chi.1",
        "season_start": "Jan",   # liga de año calendario (Ene–Dic)
        "season_end": "Dec",
    }
}


def _soccerdata_dir() -> Path:
    # soccerdata respeta la variable de entorno SOCCERDATA_DIR; si no, usa ~/soccerdata
    base = os.environ.get("SOCCERDATA_DIR")
    return Path(base) if base else Path.home() / "soccerdata"


def register_chile_league() -> Path:
    cfg_dir = _soccerdata_dir() / "config"
    cfg_dir.mkdir(parents=True, exist_ok=True)
    path = cfg_dir / "league_dict.json"

    current = {}
    if path.exists():
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            current = {}

    current.update(CHILE_ENTRY)
    path.write_text(json.dumps(current, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"[league_setup] Liga chilena registrada en: {path}")
    return path


def verify() -> bool:
    """Comprueba que soccerdata ya reconoce la liga."""
    import soccerdata as sd
    leagues = sd.FBref.available_leagues()
    ok = "CHI-Primera División" in leagues
    print(f"[league_setup] available_leagues incluye Chile: {ok}")
    if not ok:
        print("  -> Reinicia el proceso Python tras registrar (se lee al importar).")
    return ok


if __name__ == "__main__":
    register_chile_league()
    verify()
